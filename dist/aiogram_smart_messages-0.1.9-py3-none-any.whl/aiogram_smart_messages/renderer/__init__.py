# -*- coding: utf-8 -*-
from .bot_messages import SmartMessageRenderer

__all__ = ["SmartMessageRenderer"]
